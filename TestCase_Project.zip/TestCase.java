package Project_sele2;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.reporters.jq.Main;

public class TestCase {
	
	  @Test
	  public void CheckSignUp() {
		  
		  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.qa.jbktest.com/online-exam#Testing");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			Actions actions = new Actions(driver);
			
			driver.findElement(By.xpath("//p [text () = 'Manual Testing(ISTQB)']")).click();
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
			driver.findElement(By.id("loginbtn")).click();
			driver.findElement(By.id("signup-tab")).click();
			driver.findElement(By.id("name")).sendKeys("Vaishnavi Mahalle");
			driver.findElement(By.id("emailid")).sendKeys("vaishnavimahalle233@gmail.com");
			driver.findElement(By.id("mobile")).sendKeys("9998887776");
			
			actions.sendKeys(Keys.TAB) .perform();
			
			driver.findElement(By.id("agree")).click();
			driver.findElement(By.id("emailbtn")).click();
			
			String expmsg = "Sign Up";
		      String actmsg = driver.findElement(By.xpath("//*[@id='signup-tab']")).getText();
		      
		      Assert.assertEquals(actmsg,expmsg);
	  }
	 @Test
	  public void checkExam1Func() {
				
				System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
				WebDriver driver=new ChromeDriver();
				driver.get("https://www.qa.jbktest.com/online-exam#Testing");
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Actions actions = new Actions(driver);
				driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
				
				String val=driver.findElement(By.name("count")).getAttribute("value");
				System.out.println(val);
				driver.findElement(By.id("countbtn")).click();
				driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
				driver.findElement(By.id("loginbtn")).click();
				
				int num=Integer.parseInt(val);
				for(int i=1;i<=num-1;i++)
			{
					WebElement ele =driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
					JavascriptExecutor executor = (JavascriptExecutor)driver;
				      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
				}     
				  
			     WebElement ele = driver.findElement(By.id("qsubmit"));
			     JavascriptExecutor executor = (JavascriptExecutor)driver;
			      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
			      
			      String expexam = "Your Result" ;
			      String actexam = driver.findElement(By.xpath("quizheading")).getText();
			     
			      Assert.assertEquals(actexam,expexam);
			}
			
 
	 
	  @Test
	  public void CheckExam2Func(){

	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://www.qa.jbktest.com/online-exam#Testing");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
	  driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).click();
	  String val =
	 driver.findElement(By.xpath("//*[@id='quizcount']/div[1]/input[2]")).getAttribute("value");
	  System.out.println(" Attempted Questions --> " +val);
	  driver.findElement(By.id("countbtn")).click();
	  driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	  driver.findElement(By.id("loginbtn")).click();
	  int num=Integer.parseInt(val);
	  for(int i=0;i<=num+2;i++)
	  {
	  WebElement nextButton =
	 driver.findElement(By.xpath("//*[@id='quizsection']/div[2]/a[1]"));
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].click()", nextButton);


	  driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

	  }

	  driver.findElement(By.id("qsubmit")).click();

	  String msg =driver.findElement(By.xpath("//h3[text()='Your Result']")).getText();
	  System.out.println(msg);

	  String expectedResulte="Your Result";
	  String actualResult=driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	  Assert.assertEquals(actualResult, expectedResulte);
		      
  }
  
  @Test
  public void CheckExam3Fun() {
	  
	        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.qa.jbktest.com/online-exam#Testing");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
			driver.findElement(By.xpath("//*[@id=\"quizcount\"]/div[1]/input[3]")).click();
			String val =
		    driver.findElement(By.xpath("//*[@id=\"quizcount\"]/div[1]/input[3]")).getAttribute("value");
            System.out.println("Attempted Question-->" + val);
			driver.findElement(By.id("countbtn")).click();
			driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
			driver.findElement(By.id("loginbtn")).click();
			
			int num=Integer.parseInt(val);
			for(int i=0;i<=num+3;i++)
			{
				 WebElement nextButton =
						 driver.findElement(By.xpath("//*[@id=\"quizsection\"]"));
						  JavascriptExecutor js = (JavascriptExecutor)driver;
						  js.executeScript("arguments[0].click()", nextButton);
						  
			driver.navigate().to("https://www.qa.jbktest.com/online-exam#Testing");

			}     
			   
		    driver.findElement(By.id("qsubmit")).click();
		    
		    String msg=driver.findElement(By.xpath("//h3[text() = 'Your Result']")).getText();
		    System.out.println(msg);
		   
		    String expectedResulte = "Your Result" ;
		    String actualResult  = driver.findElement(By.xpath("//*[text() = 'Your Result']")).getText();
		    Assert.assertEquals(actualResult,expectedResulte );
		     }
  
  @Test
  public void CheckMyProfile() {
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p [text () = 'Manual Testing(ISTQB)']")).click();
		
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		driver.findElement(By.id("loginbtn")).click();
		
		driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[6]/div/div/div/div[1]/div/a")).click();
		driver.findElement(By.id("name")).clear();
		driver.findElement(By.id("emailid")).clear();
		driver.findElement(By.id("mobile")).clear();
		
		driver.findElement(By.id("name")).sendKeys("Vaishnavi Mahalle");
		driver.findElement(By.id("emailid")).sendKeys("vaishnavimahalle233@gmail.com");
		driver.findElement(By.id("mobile")).sendKeys("9998887776");
		driver.findElement(By.id("updatebtn")).click();
		
		String expupdatemsg = "Profile successfully updated";
		String actupdatemsg = driver.findElement(By.xpath("//*[text()='Profile successfully updated']")).getText();
		
		Assert.assertEquals(actupdatemsg,expupdatemsg);
		}
  
  
  @Test
  public void CheckGoodScore() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Actions actions = new Actions(driver);
		
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div[1]/div/a")).click();
		
		
		String expscore = "Good Score";
		String actscore = driver.findElement(By.xpath("//div[2]/div/div/h4")).getText();
		
		Assert.assertEquals(actscore,expscore);
  }
  
  @Test
  public void CheckFailedAttempt() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Actions actions = new Actions(driver);
		
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div/div[1]/div/a")).click();
		
		String expattempt = "Failed Attempt";
		String actattempt = driver.findElement(By.xpath("//div[1]/h4")).getText();
		
		Assert.assertEquals(actattempt,expattempt);
  }
  
  @Test
  public void CheckViewAnswer() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		
		String val=driver.findElement(By.name("count")).getAttribute("value");
		System.out.println(val);
		driver.findElement(By.xpath("//*[@id=\"quizcount\"]/div[1]/input[2]")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		driver.findElement(By.id("loginbtn")).click();
		
		int num=Integer.parseInt(val);
		for(int i=1;i<=num-1;i++)
		{
			WebElement ele =driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
			JavascriptExecutor executor = (JavascriptExecutor)driver;
		      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
		}     
		   
	     WebElement ele = driver.findElement(By.id("qsubmit"));
	     JavascriptExecutor executor = (JavascriptExecutor)driver;
	      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
	      
	   
	    
	      driver.findElement(By.xpath("//*[@id=\"quizresult\"]/div[2]")).click();

	      String expanswer = "Check Your Answers";
		    String actanswer = driver.findElement(By.xpath("//*[text()='Check Your Answers']")).getText();
		    
		    Assert.assertEquals(actanswer,expanswer);
  }

  

  @Test
  public void CheckTimeLine() {
	  System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Actions actions = new Actions(driver);
		
		driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
		driver.findElement(By.id("countbtn")).click();
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		driver.findElement(By.id("loginbtn")).click();
		driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
		driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[4]/div/div/div/div[1]/div/a")).click();
		
		String expchart = "canvasjs-chart-canvas";
		String actchart = driver.findElement(By.xpath("//canvas[@class='canvasjs-chart-canvas'][1]")).getText();
		
		Assert.assertEquals(actchart,expchart);
		

  }
  
  @Test
  public void CheckConttribut() {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qa.jbktest.com/online-exam#Testing");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		Actions action = new Actions(driver);
		
		driver.findElement(By.xpath("//*[text()='Manual Testing(ISTQB)']")).click();
		//next btn
		driver.findElement(By.xpath("//*[@id='countbtn']")).click();
		//enter mobile no
		driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
		// login btn
		driver.findElement(By.id("loginbtn")).click();
		// myaccount
		driver.findElement(By.xpath("//*[@id='myaccount']/a[1]")).click();
		//contribute
		driver.findElement(By.xpath("//*[@id='navbarResponsive']/div/a")).click();
		// full name
		driver.findElement(By.xpath("//div[1]/input")).sendKeys("Vaishnavi Mahalle");
		//gmail
		driver.findElement(By.xpath("//div[2]/input")).sendKeys("vaishnavimahalle@mail.com");
		//Phone number
		driver.findElement(By.xpath("//*[@id='phone']")).sendKeys("9998887776");
		//contibuor
		driver.findElement(By.xpath("//*[@id='exampleFormControlSelect1']")).sendKeys("Contibutor");
		//submit
		driver.findElement(By.xpath("//form/button")).click();	
		
		String expmsg = "Mail Sent. Thank you Vaishnavi Mahalle, we will contact you shortly.";
		String actmsg = driver.findElement(By.xpath("//*[@id='mail_success']")).getText();
		
		Assert.assertEquals(actmsg,expmsg);
}
@Test 
public void CheckTestAttempt() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.qa.jbktest.com/online-exam#Testing");
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	Actions actions = new Actions(driver);
	
	driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	driver.findElement(By.id("loginbtn")).click();
	driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
	driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[4]/div/div/div/div[1]/div/a")).click();
	
	String expattempt = "Test Attempted";
	String actattempt = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[1]/div/div/div/div[1]/div/a")).getText();
	
	Assert.assertEquals(actattempt,expattempt);
}
@Test
public void CheckPlacement() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.qa.jbktest.com/online-exam#Placement-Policy");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/a[1]")).click();
	
	Actions action = new Actions(driver);

	driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
	driver.findElement(By.id("countbtn")).click();
    driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
    driver.findElement(By.id("loginbtn")).click();
  
    driver.findElement(By.id("signup-tab")).click();
    driver.findElement(By.id("name")).sendKeys("Vaishnavi Mahalle");
    driver.findElement(By.id("emailid")).sendKeys("vaishnavimahalle23@gmail.com");
    driver.findElement(By.id("mobile")).sendKeys("9998887776");
    
    action.sendKeys(Keys.TAB).perform();
   
    driver.findElement(By.id("agree")).click();
    driver.findElement(By.id("emailbtn")).click();
    
    String expexam = "Sorry!!!";
	String actexam = driver.findElement(By.xpath("//*[@id='msg']/h3")).getText();
	
	Assert.assertEquals(actexam,expexam);
 }
@Test
 public void CheckTesttt() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.qa.jbktest.com/online-exam#testtttt");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//*[@id=\"testtttt\"]/h3")).click();
	
	String val=driver.findElement(By.name("count")).getAttribute("value");
	System.out.println(val);
	driver.findElement(By.xpath("//*[@id=\"quizcount\"]/div[1]/input[2]")).click();
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	driver.findElement(By.id("loginbtn")).click();
	
	int num=Integer.parseInt(val);
	for(int i=1;i<=num-1;i++)
	{
		WebElement ele =driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
	      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
	}     
	   
     WebElement ele = driver.findElement(By.id("qsubmit"));
     JavascriptExecutor executor = (JavascriptExecutor)driver;
      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
      
     driver.findElement(By.xpath("//*[@id=\"quizresult\"]/div[2]")).click();
     
     String expexam = "Your Result" ;
     String actexam = driver.findElement(By.xpath("quizheading")).getText();
    
     Assert.assertEquals(actexam,expexam);
}
@Test
public void CheckTesttt1() {
System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
WebDriver driver=new ChromeDriver();

Actions actions = new Actions(driver);

driver.get("https://www.qa.jbktest.com/online-exam#testtttt");
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
driver.findElement(By.xpath("//*[@id=\"testtttt\"]/div/div[2]")).click();


String val=driver.findElement(By.name("count")).getAttribute("value");
System.out.println(val);
driver.findElement(By.id("countbtn")).click();
driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
driver.findElement(By.id("loginbtn")).click();

int num=Integer.parseInt(val);
for(int i=1;i<=num-1;i++)
{
	WebElement ele =driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
	JavascriptExecutor executor = (JavascriptExecutor)driver;
      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
}     
   
 WebElement ele = driver.findElement(By.id("qsubmit"));
 JavascriptExecutor executor = (JavascriptExecutor)driver;
  ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
  
  String expmsg = "Your Result";
  String actmsg = driver.findElement(By.xpath("//*[text()='Your Result']")).getText();
	
  Assert.assertEquals(actmsg, expmsg);
}
@Test
public void CheckTesttt2() {
	
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	
	Actions actions = new Actions(driver);
	
	driver.get("https://www.qa.jbktest.com/online-exam#testtttt");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//*[@id=\"testtttt\"]/div/div[1]")).click();
	
	
	String val=driver.findElement(By.name("count")).getAttribute("value");
	System.out.println(val);
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	driver.findElement(By.id("loginbtn")).click();
	
	int num=Integer.parseInt(val);
	for(int i=1;i<=num-1;i++)
	{
		WebElement ele =driver.findElement(By.xpath("//*[@id=\"quizsection\"]/div[2]/a[1]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
	      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
	}     
	   
     WebElement ele = driver.findElement(By.id("qsubmit"));
     JavascriptExecutor executor = (JavascriptExecutor)driver;
      ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ele);
      
      String expmsg = "Sorry!!! No Questions Found";
		String actmsg = driver.findElement(By.xpath("//*[@id='noquestion']/h3")).getText();
		
		Assert.assertEquals(actmsg, expmsg);
	
}
@Test
public void CheckTotalTestTopice() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.qa.jbktest.com/online-exam#Testing");
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	Actions actions = new Actions(driver);
	
	driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	driver.findElement(By.id("loginbtn")).click();
	driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
	driver.findElement(By.xpath(" /html/body/div[1]/div[1]/div[1]/div[2]/div/h1")).click();
	
	String expmsg = "Dashboard";
	String actmsg = driver.findElement(By.xpath("//div[2]/div[1]/div[1]/h4")).getText();
	
	Assert.assertEquals(actmsg,expmsg);
}
@Test
public void CheckTotalTopiceCovered() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.qa.jbktest.com/online-exam#Testing");
	
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	Actions actions = new Actions(driver);
	
	driver.findElement(By.xpath("//p[text()='Manual Testing(ISTQB)']")).click();
	driver.findElement(By.id("countbtn")).click();
	driver.findElement(By.id("loginmobile")).sendKeys("9998887776");
	driver.findElement(By.id("loginbtn")).click();
	driver.findElement(By.xpath("//*[@id=\"myaccount\"]/a[1]")).click();
	driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[5]/div/div/div/div[1]/div/a")).click();
	
	String expmsg = "Total Topics Covered";
	String actmsg = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div[2]/div[5]/div/div")).getText();
	
	Assert.assertEquals(actmsg,expmsg);
	
}
@Test 
public void CheckFuncSingUp() {

System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.get("file:///C:/Users/Hp/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/index.html");


driver.manage().deleteAllCookies();

String label=	driver.findElement(By.xpath("/html/body/div/div[2]")).getText();
System.out.println(label);


WebElement we =driver.findElement(By.xpath("//*[@id=\"email\"]")); 
we.sendKeys("kiran@gmail.com");
WebElement we1 =driver.findElement(By.xpath("//*[@id=\"password\"]"));
we1.sendKeys("123456");
WebElement we2 =driver.findElement(By.xpath("//*[@id=\"form\"]/div[3]/div/button"));
we2.click();

driver.findElement(By.xpath("/html/body/div/aside[1]/section/ul/li[3]/a/span")).click();

String headingAct= driver.findElement(By.xpath("/html/body/div/div[2]/p")).getText();
String expHeading ="Sign in to start your session";
if(headingAct.equals(expHeading)) {
	System.out.println("correct");
}	else {
  System.out.println("incorrect");
}
}
@Test
public void checkHeading() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("file:///C:/Users/Hp/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/index.html");

driver.findElement(By.xpath("/html/body/div/aside[1]/section/ul/li[3]/a/span")).click();

String headingAct= driver.findElement(By.xpath("/html/body/div/div[2]/p")).getText();
String expHeading ="Sign in to start your session";
Assert.assertEquals( headingAct,expHeading );
}

@Test
public void CkeckUserTestCase() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("file:///C:/Users/Hp/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
	
	ArrayList<String>actList = new ArrayList<String>();
	
	for(int i=2; i<9; i++) {
		String headingAct = driver.findElement(By.xpath("/html/body/div[1]/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th["+i+"]")).getText();
		
		actList.add(headingAct);
	}
	ArrayList<String> expList = new ArrayList<String>();
	expList.add("Username");
	expList.add("Email");
	expList.add("Mobile");
	expList.add("Course");
	expList.add("Gender");
	expList.add("State");
	expList.add("Action");
	
	Assert.assertEquals(actList, expList);
}
@Test
public void checkCourses() {
	System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("file:///C:/Users/Hp/Downloads/javabykiran-Selenium-Softwares/javabykiran-Selenium-Softwares/Offline%20Website/pages/examples/users.html");
	
	ArrayList<String>actListCourses = new ArrayList<String>();
	
	for(int i=2; i<6; i++) {
		String coursesAct = driver.findElement(By.xpath("/html/body/div[1]/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr["+i+"]/td[5]")).getText();
		
		actListCourses.add(coursesAct);
	}
	ArrayList<String> expListCourses = new ArrayList<String>();
	expListCourses.add("Java/J2EE");
	expListCourses.add("Selenium");
	expListCourses.add("Python");
	expListCourses.add("PHP");
	
	Assert.assertEquals(actListCourses, expListCourses);
}
}


	

 
  
  
  
  
  
  
  
  
